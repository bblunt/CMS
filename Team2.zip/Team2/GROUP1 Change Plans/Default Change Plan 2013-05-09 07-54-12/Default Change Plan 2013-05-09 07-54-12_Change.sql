-- <ScriptOptions statementTerminator=";" />
DROP PROCEDURE GROUP1.CURINVENTORY_UPD( INTEGER, INTEGER, INTEGER );
