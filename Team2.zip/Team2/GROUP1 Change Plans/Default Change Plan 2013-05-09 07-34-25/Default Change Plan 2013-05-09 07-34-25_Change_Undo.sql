-- <ScriptOptions statementTerminator="!" />
CREATE PROCEDURE CurInventory_Sel (	IN	@Location_ID	INT,
									IN	@Active			CHAR(1),
									IN	@NeedsOrdering	CHAR(1))
	DYNAMIC RESULT SETS 1
P1: BEGIN

	DECLARE CurInventory CURSOR WITH RETURN for
	
	SELECT	sup.Supply_ID, sup.name, sl.Delivery_ID, sl.Quantity_On_Hand,
			sl.Economic_Order_Quantity, loc.Address, sup.Last_Order, sup.Active
	FROM	group1.Supply						AS	sup
	JOIN	group1.Supply_Delivery_Location		AS	sdl
	ON		sup.Supply_ID	=	sdl.Supply_ID
	JOIN	group1.Supply_Location				AS	sl
	ON		sdl.Location_ID	=	sl.Location_ID
	JOIN	group1.Location					AS	loc
	ON		sl.Location_ID	=	loc.Location_ID
	WHERE	(	@Location_ID	=	0			OR	sl.Location_ID		=	@Location_ID				)
	AND		(	@Active			=	'N'			OR	sup.Active			=	@Active						)
	AND		(	@NeedsOrdering	=	'N'			OR	sl.Quantity_On_Hand <=	sl.Economic_Order_Quantity	);
	
	OPEN CurInventory;
END P1!
