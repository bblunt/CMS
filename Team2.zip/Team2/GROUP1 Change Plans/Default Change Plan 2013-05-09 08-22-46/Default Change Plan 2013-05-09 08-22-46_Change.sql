-- <ScriptOptions statementTerminator=";" />
DROP PROCEDURE GROUP1.CURINVENTORY_UPD( INTEGER, DECIMAL(5,0) );
