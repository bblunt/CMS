-- <ScriptOptions statementTerminator="!" />
CREATE PROCEDURE CurInventory_Upd (	IN	@Delivery_ID	INT,
									IN	@NewQuantity	DECIMAL)
	DYNAMIC RESULT SETS 1
P1: BEGIN
	UPDATE	Supply_Location
	SET		Quantity_On_Hand	=	@NewQuantity
	WHERE	Delivery_ID			=	@Delivery_ID;
END P1!
