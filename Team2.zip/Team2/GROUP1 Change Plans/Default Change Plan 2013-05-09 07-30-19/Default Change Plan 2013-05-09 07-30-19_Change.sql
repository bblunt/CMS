-- <ScriptOptions statementTerminator=";" />
DROP PROCEDURE GROUP1.CURINVENTORY_SEL( INTEGER, CHAR(1), CHAR(1) );
