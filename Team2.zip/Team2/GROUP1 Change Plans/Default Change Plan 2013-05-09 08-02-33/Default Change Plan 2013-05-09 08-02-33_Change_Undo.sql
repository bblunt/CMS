-- <ScriptOptions statementTerminator="!" />
CREATE PROCEDURE CurInventory_Upd (	IN	@Location_ID	INT,
									IN	@Delivery_ID	INT,
									IN	@NewQuantity	DECIMAL)
	DYNAMIC RESULT SETS 1
P1: BEGIN
	UPDATE	Supply_Location
	SET		Quantity_On_Hand	=	@NewQuantity
	WHERE	Location_ID			=	@Location_ID
	AND		Delivery_ID			=	@Delivery_ID;
END P1!
